from django.apps import AppConfig


class SessionwordsAppConfig(AppConfig):
    name = 'sessionwords_app'
